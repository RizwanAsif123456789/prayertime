﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Assignment03.Models;

namespace Assignment03.Controllers
{
    public class PrayersTimeController : Controller
    {
        MosquesRecordDataContext dc = new MosquesRecordDataContext(); 
        public ActionResult AddMosque()
        {
            var r = dc.MosquesRecords.Select(rec => rec.Area).Distinct();
            return View(r.ToList());
        }

        public ActionResult AddDetails()
        {
            MosquesRecord mr = new MosquesRecord();

            mr.Name = Request["name"];
            string ar = Request["area"];
            if (ar == "Others")
                mr.Area = Request["addArea"];
            else
                mr.Area = ar;
            string hours = Request["fajrHours"];
            string minutes = Request["fajrMinutes"]; 
            
            if (hours != "" && minutes != "") 
                mr.Fajer = hours + " : " + minutes + "\t" + Request["fajrTime"];

            hours = Request["zuhrHours"];
            minutes = Request["zuhrMinutes"];

            if (hours != "" && minutes != "")
                mr.Zohar = hours + " : " + minutes + "\t" + Request["zuhrTime"];

            hours = Request["asrHours"];
            minutes = Request["asrMinutes"];

            if (hours != "" && minutes != "")
                mr.Aser = hours + " : " + minutes + "\t" + Request["asrTime"];

            hours = Request["maghribHours"];
            minutes = Request["maghribMinutes"];

            if (hours != "" && minutes != "")
                mr.Maghrib = hours + " : " + minutes + "\t" + Request["maghribTime"];
            
            hours = Request["ishaHours"];
            minutes = Request["ishaMinutes"];

            if (hours != "" && minutes != "")
                mr.Esha = hours + " : " + minutes + "\t" + Request["ishaTime"];
           
            dc.MosquesRecords.InsertOnSubmit(mr);
            dc.SubmitChanges();
            return RedirectToAction("AddMosque");
        }
        [HttpPost]
        public ActionResult viewMosquesDetails()
        {
            string area = Request["SelectAreas"];
            ViewBag.data = area;
            if (area != "all")
            {
                var r = dc.MosquesRecords.Where(rec => rec.Area == area);
                return View(r.ToList());
            }
            else
            {
                var r = dc.MosquesRecords.Select(rec => rec);
                return View(r.ToList());
            }
        }
        public ActionResult viewRecords()
        {
            var r = dc.MosquesRecords.Select(rec => rec.Area).Distinct();
            return View(r.ToList());
        }
        public ActionResult editRecords()
        {
            var r = dc.MosquesRecords.Select(rec => rec);
            return View(r.ToList());
        }
        public ActionResult Delete(int id)
        {
            ViewBag.data = id;
            var r = dc.MosquesRecords.First(rec => rec.Id == id);
            dc.MosquesRecords.DeleteOnSubmit(r);
            dc.SubmitChanges();

            return RedirectToAction("viewRecords");
        }

        public ActionResult Edit(int id)
        {
            Session["Id"] = id;
            ViewBag.data = dc.MosquesRecords.Select(rec => rec.Area).Distinct();
            return View();
        }
        
        public ActionResult Temp()
        {
            MosquesRecord mr = new MosquesRecord();
            var r = dc.MosquesRecords.First(rec => rec.Id == Convert.ToInt32(Session["Id"]));
            r.Name = Request["name"];
            string ar = Request["area"];
            
            if (ar == "Others")
                r.Area = Request["addArea"];
            else
                r.Area = ar;

            if (Request["fajrHours"] != "" && Request["fajrMinutes"] != "")
                r.Fajer = Request["fajrHours"] + " : " + Request["fajrMinutes"] + "\t" + Request["fajrTime"];

            if (Request["zuhrHours"] != "" && Request["zuhrMinutes"] != "")
                r.Zohar = Request["zuhrHours"] + " : " + Request["zuhrMinutes"] + "\t" + Request["zuhrTime"];

            if (Request["asrHours"] != "" && Request["asrMinutes"] != "")
                r.Aser = Request["asrHours"] + " : " + Request["asrMinutes"] + "\t" + Request["asrTime"];

            if (Request["maghribHours"] != "" && Request["maghribMinutes"] != "")
                r.Maghrib = Request["maghribHours"] + " : " + Request["maghribMinutes"] + "\t" + Request["maghribTime"];

            if (Request["ishaHours"] != "" && Request["ishaMinutes"] != "")
                r.Esha = Request["ishaHours"] + " : " + Request["ishaMinutes"] + "\t" + Request["ishaTime"];
            
            dc.SubmitChanges();
           
            return RedirectToAction("viewRecords");
        }
	}
}